const config = {
  apiUrl: '/api_shota_nishinaga'
};

export default config;  