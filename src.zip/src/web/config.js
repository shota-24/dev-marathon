const config = {
  apiUrl: 'http://localhost:5230'
};

export default config;